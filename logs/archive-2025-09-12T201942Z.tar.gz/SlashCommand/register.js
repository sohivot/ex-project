const {
  ActionRowBuilder,
  PermissionsBitField,
  ButtonStyle,
  ButtonBuilder,
  SlashCommandBuilder,
  EmbedBuilder
} = require("discord.js")
const cfg = require('../config.json')


module.exports = {
  data: new SlashCommandBuilder()
    .setName("register")
    .setDescription("Create Buttons Create Account!"),
  run: async (client, interaction) => {
    const userid = interaction.user.id
    if (userid != cfg.ownerBot[0]) return interaction.reply({ content: '**Hanya bisa dilakukan owner bot**', ephemeral: true })
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    const embedMes = new EmbedBuilder()
      .setColor('Blue')
      //.setDescription(`Halo selamat datang di server ${cfg.serverName}! Disini tempat kamu membuat akun, silahkan baca dulu ketentuannya lalu buatlah akun mu!`)
      .addFields({ name: `__**Register**__ 💾`, value: `> Jika kamu belum mempunyai akun dan ingin membuat akun tekan saja tombol register di bawah.` })
      .addFields({ name: `__**Re-Verified**__ 📌`, value: `> Jika kamu sempat keluar dari discord server ini kamu bisa memverifikasi ulang akun mu dengan menekan tombol reverif di bawah.` })
        .addFields({name:`__**Check Stats 💾**__`, value:`> Tombol ini digunakan untuk mengecek statisik karakter yang ada di dalam game!`})
        .addFields({name: `__**Resend Pin Code ♻️**__`, value: `> Jika kamu tidak mendapati pin verifikasi kamu bisa tekan tomvol resend pin code di bawah untuk mengirim kembali pin.` })
      .setTimestamp()
      //.setImage(`${cfg.registerBanner}`)
      .setAuthor({ name: `${cfg.serverName}`, iconURL: `${cfg.serverImage}` })
      .setFooter({ text: `${cfg.serverFooter}` })

    const butRegister = new ButtonBuilder()
      .setCustomId("register-buttons")
      .setLabel("Register")
      .setEmoji('🎟️')
      .setStyle(ButtonStyle.Primary)

    const butCode = new ButtonBuilder()
      .setCustomId("register-kode")
      .setLabel("Reverif")
      .setEmoji('📌')
      .setStyle(ButtonStyle.Secondary)

    const butStats = new ButtonBuilder()
      .setCustomId("ingame-stats")
      .setLabel("Check Stats")
      .setEmoji('💾')
      .setStyle(ButtonStyle.Success)

    const butRes = new ButtonBuilder()
      .setCustomId("resend-pin")
      .setLabel("Resend Code")
      .setEmoji('♻️')
      .setStyle(ButtonStyle.Danger)


    let row = new ActionRowBuilder().addComponents(butRegister, butCode, butStats, butRes)
    interaction.channel.send({ embeds: [embedMes], components: [row] })
  }
};