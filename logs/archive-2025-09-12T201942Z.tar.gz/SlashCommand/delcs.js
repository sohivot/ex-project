const {
    ActionRowBuilder,
    PermissionsBitField,
    ButtonStyle,
    ButtonBuilder,
    SlashCommandBuilder,
    EmbedBuilder
} = require("discord.js");
const cfg = require('../config.json');
const con = require('../mysql')

module.exports = {
    data: new SlashCommandBuilder()
        .setName('delcs')
        .setDescription('Delete Characterstory!')
        .addStringOption(option =>
            option.setName('username')
                .setDescription('Character Name')
                .setRequired(true))
        .addUserOption(option =>
            option.setName('discordakun')
                .setDescription('Tag Discord Account')
                .setRequired(true)),
    run: async (client, interaction) => {
        const member = interaction.member;
        const memberRoles = member.roles.cache;
        let hasStaffRole = false;
        memberRoles.forEach((role) => {
            if (cfg.staffrole.includes(role.id)) {
                hasStaffRole = true;
            }
        });
        if (!hasStaffRole) return interaction.reply({ content: `**[${cfg.botName}]: Hanya bisa dilakukan oleh Staff**`, ephemeral: true });
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

        // Mengakses opsi "username"
        const username = interaction.options.getString("username");

        if (username.includes(" ") === true) {
            return interaction.reply({ content: `**[${cfg.botName}]: Nama karakter tidak menggunakan spasi.**`, ephemeral: true })
        }

        con.query(`SELECT * FROM player_characters WHERE Char_Name = '${username}'`, (err, res) => {
            if (err) return console.log(err);
            if (res[0]) {
                if (res[0].cschar == 0) {
                    return interaction.reply({ content: `**[${cfg.botName}]: Karakter tersebut belum mempunyai Character Story!**`, ephemeral: true })
                }
                else {
                    const channel = interaction.guild.channels.cache.get(cfg.logsCs);
                    const user = interaction.user;
                    const discord = interaction.options.getUser("discordakun");
                    channel.send({ content: `**[${cfg.botName}]: <@${discord.id}> Salah satu karaktermu __${username}__ telah di hapus character story oleh admin <@${user.id}>**` });
                    interaction.reply({ content: `**[${cfg.botName}]: Berhasil menghapus Character Story ke ${username}**`, ephemeral: true });
                    con.query(`UPDATE player_characters SET Char_Story ='0' WHERE username = '${username}'`)
                }
            } else {
                return interaction.reply({ content: `**[${cfg.botName}]: Gagal menghapus character story karena karakter tidak di temukan!**`, ephemeral:true })
            }
        })
    }
};
