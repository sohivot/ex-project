const client = require('../index')

client.on('messageCreate', async message => {
    if(message.author.bot || message.channel.type === "DM") return;
});