const client = require('..')
const crypto = require('crypto');
const con = require('../mysql')
const cfg = require('../config.json')
const {
    ModalBuilder,
    ActionRowBuilder,
    TextInputBuilder,
    TextInputStyle,
    EmbedBuilder
} = require("discord.js")

client.on('interactionCreate', async (interaction) => {
    const userid = interaction.user.id;
    if (interaction.isCommand()) {
        if (interaction.user.bot) return;
        try {
            const command = client.slashcommands.get(interaction.commandName)
            command.run(client, interaction)
        } catch {
            return interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
        } finally {
            console.log(`\x1b[31m[BOT]: \x1b[37mUser \x1b[31m${interaction.member.displayName}: \x1b[37mHas Using command \x1b[31m(/${interaction.commandName})\x1b[0m`)
        }
    }
    if (interaction.isButton()) {
        console.log(`\x1b[31m[BOT]: \x1b[37mUser \x1b[31m${interaction.member.displayName}: \x1b[37mHas Using buttons \x1b[31m(${interaction.customId})\x1b[0m`)
        /* ====================================== Buttons Section ============================= */
        if (interaction.customId === "register-kode") {
            con.query(`SELECT * FROM playerucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    con.query(`SELECT * FROM playerucp WHERE DiscordID = ${userid}`, (err, res) => {
                        if (err) return console.log(err);
                        const errEm = new EmbedBuilder()
                            .setColor('Green')
                            .setTitle("Success Message")
                            .setDescription(`**[${cfg.botName}]: ✅ - Kamu berhasil memverifikasi ulang akunmu, silahkan cek DM(Direct Message).**`)
                            .setTimestamp()
                            .setFooter({ text: `${cfg.serverFooter}` })

                        interaction.member.roles.add(cfg.memberrole[0])
                        interaction.reply({ embeds: [errEm], ephemeral: true })

                        const apani = 0;
                        var randomCode = Math.floor(Math.random() * 99999) + 1;
                        con.query(`UPDATE playerucp SET verifycode ='${randomCode}' WHERE DiscordID = '${userid}'`)

                        const msgEmbed = new EmbedBuilder()
                            .setAuthor({ name: `${cfg.serverName}`, iconURL: `${cfg.serverImage}` })
                            .setColor('Blue')
                            .setDescription(`Halo! Akun UCP mu berhasil terverifikasi ulang, silahkan gunakan pin baru di bawah untuk login ke game!`)
                            .addFields({ name: `UCP`, value: `\`\`\`${res[0].ucp}\`\`\`` })
                            .addFields({ name: "Pin", value: `> ||${randomCode}||\n\n__klik kotak hitam untuk melihat pin!__` })
                            .setFooter({ text: `${cfg.serverFooter}` })
                        interaction.member.send({ embeds: [msgEmbed] }).catch(e => {
                            if (e) return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Gagal memverifikasi ulang, ubah terlebih dahulu permission DM anda.**`, ephemeral: true })
                        })
                    })
                } else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu tidak terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "resend-pin") {
            con.query(`SELECT * FROM playerucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    con.query(`SELECT * FROM playerucp WHERE DiscordID = ${userid}`, (err, res) => {
                        if (err) return console.log(err);
                        if (res[0].verifemail == 1) {
                            interaction.reply({ content: `**[${cfg.botName}]: ❎ - Gagal mengirim ulang pin karena anda sudah terdaftar di ingame.**`, ephemeral: true })
                        } else {
                            const errEm = new EmbedBuilder()
                                .setColor('Green')
                                .setTitle("Success Message")
                                .setDescription(`**[${cfg.botName}]: ✅ - Pin akunmu berhasil di kirim ulang!.**`)
                                .setTimestamp()
                                .setFooter({ text: `${cfg.serverFooter}` })
                            interaction.reply({ embeds: [errEm], ephemeral: true })

                            const msgEmbed = new EmbedBuilder()
                                .setAuthor({ name: `${cfg.serverName}`, iconURL: `${cfg.serverImage}` })
                                .setColor('Blue')
                                .setDescription(`Halo! pin berhasil di kirim ulang, cek pin di bawah untuk masuk ke dalam game`)
                                .addFields({ name: `UCP`, value: `\`\`\`${res[0].ucp}\`\`\`` })
                                .addFields({ name: "Pin", value: `> ||${res[0].verifycode}||\n\n__Klik kotak hitam untuk melihat pin!__` })
                                .setFooter({ text: `${cfg.serverFooter}` })
                            interaction.member.send({ embeds: [msgEmbed] }).catch(e => {
                                if (e) return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Gagal mengirim ulang pin, ubah terlebih dahulu permission DM anda.**`, ephemeral: true })
                            })
                        }
                    })
                } else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu belum terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "register-buttons") {
            const userCreatedTimestamp = interaction.user.createdTimestamp;
            const minAccountAge = 3 * 24 * 60 * 60 * 1000; // Usia akun minimum dalam milidetik (15 hari)
        
            if (Date.now() - userCreatedTimestamp < minAccountAge) {
                return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun Discord Anda harus berumur minimal 3 hari untuk melakukan registrasi.**`, ephemeral: true });
            }
            con.query(`SELECT * FROM playerucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (!res[0]) {
                    const registerAkun = new ModalBuilder()
                        .setCustomId("register")
                        .setTitle("Register UCP")

                    const namaAkun = new TextInputBuilder()
                        .setCustomId("reg-namaakun")
                        .setLabel("Name UCP")
                        .setPlaceholder("Enter the name you want")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(3)

                    const row = new ActionRowBuilder().addComponents(namaAkun)
                    registerAkun.addComponents(row)
                    interaction.showModal(registerAkun)
                } else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu sudah terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "reffund") {
            con.query(`SELECT * FROM playerucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const modal = new ModalBuilder()
                        .setCustomId("ModalReffund")
                        .setTitle("Request Reffund")

                    const TitleInput = new TextInputBuilder()
                        .setCustomId('Title')
                        .setMinLength(4)
                        .setMaxLength(30)
                        .setPlaceholder("Masukan Judul Reffund")
                        .setLabel("Judul Reffund")
                        .setStyle(TextInputStyle.Paragraph);

                    const DescriptionInput = new TextInputBuilder()
                        .setCustomId('Desc')
                        .setMinLength(4)
                        .setMaxLength(128)
                        .setPlaceholder("Jelaskan mengapa bisa kehilangan asset.")
                        .setLabel("Kronologi kehilangan")
                        .setStyle(TextInputStyle.Paragraph);

                    const LinkInput = new TextInputBuilder()
                        .setCustomId('Link')
                        .setMinLength(4)
                        .setMaxLength(400)
                        .setPlaceholder("Masukan link website yang berisi kan Foto / Video")
                        .setLabel("SS/FOTO BUKTI")
                        .setStyle(TextInputStyle.Paragraph);

                    const row = new ActionRowBuilder().addComponents(TitleInput)
                    const row2 = new ActionRowBuilder().addComponents(DescriptionInput)
                    const row3 = new ActionRowBuilder().addComponents(LinkInput)
                    modal.addComponents(row, row2, row3)
                    interaction.showModal(modal)
                }   else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu belum terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "unbanned") {
            con.query(`SELECT * FROM playerucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const modal = new ModalBuilder()
                        .setCustomId("ModalUnbanned")
                        .setTitle("Request Unbanned")

                    const TitleInput = new TextInputBuilder()
                        .setCustomId('Title')
                        .setMinLength(4)
                        .setMaxLength(30)
                        .setPlaceholder("Alasan terkena banned")
                        .setLabel("Reason Banned")
                        .setStyle(TextInputStyle.Paragraph);

                    const DescriptionInput = new TextInputBuilder()
                        .setCustomId('Desc')
                        .setMinLength(4)
                        .setMaxLength(128)
                        .setPlaceholder("Jelaskan kronologi dengan jelas")
                        .setLabel("Kronologi")
                        .setStyle(TextInputStyle.Paragraph);

                    const LinkInput = new TextInputBuilder()
                        .setCustomId('Link')
                        .setMinLength(4)
                        .setMaxLength(400)
                        .setPlaceholder("Masukan link website yang berisi kan ss/foto")
                        .setLabel("SS/FOTO BANNED")
                        .setStyle(TextInputStyle.Paragraph);

                    const row = new ActionRowBuilder().addComponents(TitleInput)
                    const row2 = new ActionRowBuilder().addComponents(DescriptionInput)
                    const row3 = new ActionRowBuilder().addComponents(LinkInput)
                    modal.addComponents(row, row2, row3)
                    interaction.showModal(modal)
                }   else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu belum terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "staff") {
            con.query(`SELECT * FROM playerucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const modal = new ModalBuilder()
                        .setCustomId("ModalRepStaff")
                        .setTitle("Report Staff")

                    const TitleInput = new TextInputBuilder()
                        .setCustomId('Title')
                        .setMinLength(4)
                        .setMaxLength(30)
                        .setPlaceholder("Kaitkan nama staff terlapor")
                        .setLabel("Report Staff")
                        .setStyle(TextInputStyle.Paragraph);

                    const DescriptionInput = new TextInputBuilder()
                        .setCustomId('Desc')
                        .setMinLength(4)
                        .setMaxLength(128)
                        .setPlaceholder("Jelaskan kronologi dengan jelas")
                        .setLabel("Kronologi")
                        .setStyle(TextInputStyle.Paragraph);

                    const LinkInput = new TextInputBuilder()
                        .setCustomId('Link')
                        .setMinLength(4)
                        .setMaxLength(400)
                        .setPlaceholder("Masukan link website yang berisi kan ss/foto")
                        .setLabel("SS/FOTO BUKTI")
                        .setStyle(TextInputStyle.Paragraph);

                    const row = new ActionRowBuilder().addComponents(TitleInput)
                    const row2 = new ActionRowBuilder().addComponents(DescriptionInput)
                    const row3 = new ActionRowBuilder().addComponents(LinkInput)
                    modal.addComponents(row, row2, row3)
                    interaction.showModal(modal)
                }   else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu belum terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "player") {
            con.query(`SELECT * FROM playerucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const modal = new ModalBuilder()
                        .setCustomId("ModalRepPlayer")
                        .setTitle("Report Player")

                    const TitleInput = new TextInputBuilder()
                        .setCustomId('Title')
                        .setMinLength(4)
                        .setMaxLength(30)
                        .setPlaceholder("Kaitkan nama player terlapor")
                        .setLabel("Report Player")
                        .setStyle(TextInputStyle.Paragraph);

                    const DescriptionInput = new TextInputBuilder()
                        .setCustomId('Desc')
                        .setMinLength(4)
                        .setMaxLength(128)
                        .setPlaceholder("Jelaskan kronologi dengan jelas")
                        .setLabel("Kronologi")
                        .setStyle(TextInputStyle.Paragraph);

                    const LinkInput = new TextInputBuilder()
                        .setCustomId('Link')
                        .setMinLength(4)
                        .setMaxLength(400)
                        .setPlaceholder("Masukan link website yang berisi kan ss/foto")
                        .setLabel("SS/FOTO BUKTI")
                        .setStyle(TextInputStyle.Paragraph);

                    const row = new ActionRowBuilder().addComponents(TitleInput)
                    const row2 = new ActionRowBuilder().addComponents(DescriptionInput)
                    const row3 = new ActionRowBuilder().addComponents(LinkInput)
                    modal.addComponents(row, row2, row3)
                    interaction.showModal(modal)
                }   else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu belum terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "repbug-ig") {
            con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const modal = new ModalBuilder()
                        .setCustomId("ModalReportBugIg")
                        .setTitle("Report Bug In Game")

                    const TitleInput = new TextInputBuilder()
                        .setCustomId('Title')
                        .setMinLength(4)
                        .setMaxLength(30)
                        .setPlaceholder("Masukan Judul BUG")
                        .setLabel("BUG TITLE/SUBJECT")
                        .setStyle(TextInputStyle.Paragraph);

                    const DescriptionInput = new TextInputBuilder()
                        .setCustomId('Desc')
                        .setMinLength(4)
                        .setMaxLength(128)
                        .setPlaceholder("Deskripsi BUG")
                        .setLabel("BUG DESCRIPTION")
                        .setStyle(TextInputStyle.Paragraph);

                    const LinkInput = new TextInputBuilder()
                        .setCustomId('Link')
                        .setMinLength(4)
                        .setMaxLength(400)
                        .setPlaceholder("Masukan link website yang berisi kan Foto / Video")
                        .setLabel("IMAGE/VIDEO LINK")
                        .setStyle(TextInputStyle.Paragraph);

                    const row = new ActionRowBuilder().addComponents(TitleInput)
                    const row2 = new ActionRowBuilder().addComponents(DescriptionInput)
                    const row3 = new ActionRowBuilder().addComponents(LinkInput)
                    modal.addComponents(row, row2, row3)
                    interaction.showModal(modal)
                }   else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu belum terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "CStory") {
            con.query(`SELECT * FROM playerucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const modal = new ModalBuilder()
                        .setCustomId("ModalCStory")
                        .setTitle("Request Character Story")

                    const TitleInput = new TextInputBuilder()
                        .setCustomId('Title')
                        .setMinLength(4)
                        .setMaxLength(50)
                        .setPlaceholder("Character Name")
                        .setLabel("Name (IC)")
                        .setStyle(TextInputStyle.Paragraph);

                    const DescriptionInput = new TextInputBuilder()
                        .setCustomId('Desc')
                        .setMinLength(4)
                        .setMaxLength(100)
                        .setPlaceholder("Story Character")
                        .setLabel("Faste link story")
                        .setStyle(TextInputStyle.Paragraph);

                    const LinkInput = new TextInputBuilder()
                        .setCustomId('Link')
                        .setMinLength(4)
                        .setMaxLength(200)
                        .setPlaceholder("Your Stats")
                        .setLabel("Ss/Foto (/stats)")
                        .setStyle(TextInputStyle.Paragraph);

                    const row = new ActionRowBuilder().addComponents(TitleInput)
                    const row2 = new ActionRowBuilder().addComponents(DescriptionInput)
                    const row3 = new ActionRowBuilder().addComponents(LinkInput)
                    modal.addComponents(row, row2, row3)
                    interaction.showModal(modal)
                }   else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu belum terdaftar**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "CKilled") {
            con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const modal = new ModalBuilder()
                        .setCustomId("ModalCKilled")
                        .setTitle("Request Character Killed")

                    const TitleInput = new TextInputBuilder()
                        .setCustomId('Title')
                        .setMinLength(4)
                        .setMaxLength(80)
                        .setPlaceholder("Character Name")
                        .setLabel("Old Name | New Name")
                        .setStyle(TextInputStyle.Paragraph);

                    const DescriptionInput = new TextInputBuilder()
                        .setCustomId('Desc')
                        .setMinLength(4)
                        .setMaxLength(100)
                        .setPlaceholder("Story Killed")
                        .setLabel("Faste link story")
                        .setStyle(TextInputStyle.Paragraph);

                    const LinkInput = new TextInputBuilder()
                        .setCustomId('Link')
                        .setMinLength(4)
                        .setMaxLength(200)
                        .setPlaceholder("SSRP Character Killed")
                        .setLabel("Ss/Foto CKD")
                        .setStyle(TextInputStyle.Paragraph);

                    const row = new ActionRowBuilder().addComponents(TitleInput)
                    const row2 = new ActionRowBuilder().addComponents(DescriptionInput)
                    const row3 = new ActionRowBuilder().addComponents(LinkInput)
                    modal.addComponents(row, row2, row3)
                    interaction.showModal(modal)
                }   else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Akun mu belum terdaftar**`, ephemeral: true })
                }
            })
        }
        /* ========================= Ingame Supports ================================ */
        if (interaction.customId === "ingame-stats") {
            con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const stats = new ModalBuilder()
                        .setCustomId("stats-account")
                        .setTitle(`Check Stats! UCP: ${res[0].ucp_name}`)

                    const statsac = new TextInputBuilder()
                        .setCustomId("stats-acc")
                        .setLabel("Account")
                        .setPlaceholder("Masukan nama character")
                        .setStyle(TextInputStyle.Short)
                        .setMinLength(8)
                        .setMaxLength(20)

                    const row = new ActionRowBuilder().addComponents(statsac)
                    stats.addComponents(row)
                    interaction.showModal(stats)
                } else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Kamu belum terdaftar**`, ephemeral: true })
                }
            })
        }
    }
    /*if (interaction.customId === "ingame-log") {
        con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
            if (err) return console.log(err);
            if (res.length > 0) {
                const stats = new ModalBuilder()
                    .setCustomId("chat-account")
                    .setTitle(`Check Stats! UCP: ${res[0].ucp_name}`)

                const statsac = new TextInputBuilder()
                    .setCustomId("chat-acc")
                    .setLabel("Account")
                    .setPlaceholder("Input Valid Account Name")
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(8)
                    .setMaxLength(20)

                const row = new ActionRowBuilder().addComponents(statsac)
                stats.addComponents(row)
                interaction.showModal(stats)
            } else {
                return interaction.reply({ content: `❎ - You haven't registered an account yet`, ephemeral: true })
            }
        });
    }*/
    if (interaction.isModalSubmit()) {
        /* ========================== Modals Section ================================ */
        if (interaction.customId === "stats-account") {
            const acc = interaction.fields.getTextInputValue('stats-acc')
            con.query(`SELECT * FROM playerucp WHERE ucp = '${acc}'`, (err, res) => {
                if (err) return console.log(err);
                if (res[0]) {
                    const dcname = interaction.member.displayName;
                    const ucpname = res[0].ucpname;
                    const moneyFormatted = res[0].money.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
                    const bmoneyFormatted = res[0].bmoney.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
                    if (ucpname != dcname) {
                        return interaction.reply({ content: '**karakter ini bukan milik anda!**', ephemeral: true })
                    } else {
                        const embed = new EmbedBuilder()
                            .setTitle(`Statistics`)
                            .addFields({ name: `Name Character:`, value: `${res[0].ucp}` })
                            .addFields({ name: `Money:`, value: `${moneyFormatted}` })
                            .addFields({ name: `Bank Money:`, value: `${bmoneyFormatted}` })
                            .addFields({ name: `Level:`, value: `${res[0].level}` })
                            .addFields({ name: `Birthday Date:`, value: `${res[0].age}` })
                            .addFields({ name: `Gold:`, value: `${res[0].gold}` })
                            .addFields({ name: `Hunger:`, value: `${res[0].hunger}%` })
                            .addFields({ name: `Thirst:`, value: `${res[0].energy}%` })
                            .addFields({ name: `Last Login:`, value: `${res[0].last_login}` })
                            .setImage(`https://assets.open.mp/assets/images/skins/${res[0].skin}.png`)
                            .setColor('Blue')
                        return interaction.reply({ embeds: [embed], ephemeral: true });
                    }
                } else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Karakter tidak di temukan!**`, ephemeral: true })
                }
            })
        }
        if (interaction.customId === "register") {
            const namaAkun = interaction.fields.getTextInputValue('reg-namaakun');
            if (namaAkun.includes("_") === true) {
                return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Tidak boleh memakai simbol '_'**`, ephemeral: true });
            }
        
            if (namaAkun.includes(" ") === true) {
                return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Tidak boleh memakai spasi**`, ephemeral: true });
            }
        
            var Regex = /^[a-z]+$/i;
            if (!Regex.test(namaAkun)) {
                return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Tidak boleh memakai simbol / nomor**`, ephemeral: true });
            }
        
            con.query(`SELECT * FROM playerucp WHERE ucp = '${namaAkun}'`, (err, res) => {
                if (err) {
                    console.error("Database error: ", err);
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Terjadi kesalahan pada database.**`, ephemeral: true });
                }
        
                if (!res[0]) {
                    const theCode = Math.floor(Math.random() * 99999) + 1;
                    const masukanNama = `INSERT INTO playerucp(ucp, verifycode, DiscordID) VALUES ('${namaAkun}', '${theCode}', '${userid}')`;
                    con.query(masukanNama, function (err, res) {
                        if (err) {
                            console.error("Database error: ", err);
                            return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Terjadi kesalahan pada database.**`, ephemeral: true });
                        }
        
                        if (!res[0]) {
                            const successEmbed = new EmbedBuilder()
                                .setColor('Green')
                                .setTitle("Success Message")
                                .setDescription(`**[${cfg.botName}]: ✅ - Berhasil mendaftarkan akun mu dengan nama UCP: ${namaAkun}\nCek DM(Direct Message) anda.**`)
                                .setTimestamp()
                                .setFooter({ text: `${cfg.serverFooter}` });
        
                            console.log(`Menambahkan role kepada member: ${interaction.member.id}`);
                            interaction.member.roles.add(cfg.memberrole[0]).then(() => {
                                console.log(`Role berhasil ditambahkan kepada member: ${interaction.member.id}`);
                            }).catch(error => {
                                console.error(`Gagal menambahkan role kepada member: ${interaction.member.id}`, error);
                            });
        
                            interaction.member.setNickname(`${namaAkun}`);
                            const logucp = client.channels.cache.get(cfg.logsUCP);
                            const msgLogsEmbed = new EmbedBuilder()
                                .setAuthor({ name: 'User Control Panel', iconURL: 'https://i.postimg.cc/vmY2Cn8c/server.png' })
                                .setColor('Blue')
                                .setTitle(`Account UCP Logs`)
                                .setDescription(`Name UCP: ${namaAkun}\nOwner UCP: <@${userid}>`)
                                .setFooter({ text: `${cfg.serverFooter}` })
                                .setTimestamp();
                            //logucp.send({ embeds: [msgLogsEmbed] });
        
                            interaction.reply({ embeds: [successEmbed], ephemeral: true });
                            const msgEmbed = new EmbedBuilder()
                                .setAuthor({ name: `${cfg.serverName}`, iconURL: `${cfg.serverImage}` })
                                .setColor('Blue')
                                .setDescription(`Hallo ${namaAkun}! Akun mu berhasil terdaftar, silahkan gunakan pin di bawah untuk login ke dalam game`)
                                .addFields({ name: `UCP`, value: `\`\`\`${namaAkun}\`\`\`` })
                                .addFields({ name: "Pin", value: `> ||${theCode}||\n\n__klik kotak hitam untuk melihat pin!__` })
                                .setFooter({ text: `${cfg.serverFooter}` });
        
                            interaction.member.send({ embeds: [msgEmbed] }).catch(e => {
                                console.error("Gagal mengirim pesan DM: ", e);
                                return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Tidak dapat mengirim kode ke Direct Message(DM), Silahkan ubah pengaturan terlebih dahulu**`, ephemeral: true });
                            });
                        }
                    });
                } else {
                    return interaction.reply({ content: `**[${cfg.botName}]: ❎ - Nama akun tersebut sudah ada, gunakan nama lain.**`, ephemeral: true });
                }
            });
        }
    }
});
const isURL = function (str) {
    // Regular expression untuk mengecek kevalidan URL
    const pattern = new RegExp('^(https?:\\/\\/)?' + // Protokol
        '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // Domain
        '((\\d{1,3}\\.){3}\\d{1,3}))' + // Alamat IP
        '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // Port dan path
        '(\\?[;&a-z\\d%_.~+=-]*)?' + // Query string
        '(\\#[-a-z\\d_]*)?$', 'i'); // Anchor

    // Mengecek apakah str valid URL atau tidak menggunakan regular expression
    return pattern.test(str);
};