const client = require("../index");
const { ActivityType } = require("discord.js");
const query = require("samp-query");
const cfg = require('../config.json');
const { EmbedBuilder } = require("discord.js");

client.once('ready', async () => {
    let server_ip = cfg.serverIP;
    let server_port = parseInt(cfg.serverPort, 10); // Ensure the port is a number

    console.log(`Configured server IP: ${server_ip}`);
    console.log(`Configured server port: ${server_port}`);

    const activitiesoff = [
        { name: `${cfg.serverName} | Maintenance`, type: ActivityType.Watching }
    ];
    const activitieson = [
        { name: `${cfg.serverName} | Online`, type: ActivityType.Playing }
    ];
    let i = 0;
    let isEmbedSentOff = false;
    let isEmbedSentOn = false;

    const checkServerStatus = () => {
        var samp = {
            host: server_ip,
            port: server_port
        };

        console.log(`Querying SAMP server at ${samp.host}:${samp.port}`);

        query(samp, function (error, response) {
            if (error) {
                if (i >= activitiesoff.length) i = 0;
                client.user.setActivity(activitiesoff[i]);
                client.user.setStatus('idle');
                i++;
            } else {
                if (i >= activitieson.length) i = 0;
                client.user.setActivity(activitieson[i]);
                client.user.setStatus('online');
                i++;
            }
        });
    };

    setInterval(checkServerStatus, 10000); // Adjust interval as needed
});
