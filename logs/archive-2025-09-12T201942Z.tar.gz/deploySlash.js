const { Routes } = require('discord-api-types/v9');
const { REST } = require('@discordjs/rest')
const client = require('./index')
const cfg = require("./config.json")
const fs = require("fs");
const chalk = require('chalk');
const AsciiTable = require('ascii-table');
const table = new AsciiTable().setHeading('Slash Commands', 'Stats').setBorder('|', '=', "0", "0")
const rest = new REST({ version: '9' }).setToken(cfg.tokenID)
rest.put(Routes.applicationCommands(cfg.applicationID), { body: [] })
    .then(() => console.log('deleted all application commands.'))
    .catch(console.error);


//slash-command-handler
const commands = [];
const commandFiles = fs.readdirSync('./SlashCommand').filter(file => file.endsWith('.js'))
for (const file of commandFiles) {
	const command = require(`./SlashCommand/${file}`);
	commands.push(command.data.toJSON());
    client.slashcommands.set(command.data.name, command);
    table.addRow(file.split('.js')[0], '✅')
}
console.log(chalk.red(table.toString()));

(async () => {
    try {
        console.log(`Started refreshing ${commands.length} application (/) commands.`);

        // The put method is used to fully refresh all commands in the guild with the current set
        const data = await rest.put(
            Routes.applicationGuildCommands(cfg.clientID, cfg.guildID),
            { body: commands },
        );

        console.log(`Successfully reloaded ${data.length} application (/) commands.`);
    } catch (error) {
        // And of course, make sure you catch and log any errors!
        console.error(error);
    }
})();