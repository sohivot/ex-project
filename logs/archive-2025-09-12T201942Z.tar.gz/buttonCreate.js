const client = require('../index')
const con = require('../mysql')
const {
    ModalBuilder,
    ActionRowBuilder,
    TextInputBuilder,
    TextInputStyle,
    EmbedBuilder
} = require("discord.js")

client.on('interactionCreate', (interaction) => {
    const userid = interaction.user.id;
    console.log(`\x1b[31m[BOT]: \x1b[37mUser \x1b[31m${interaction.member.displayName}: \x1b[37mHas Using buttons \x1b[31m(${interaction.customId})\x1b[0m`)
    /* ====================================== Buttons Section ============================= */
    if (interaction.customId === "register-kode") {
        con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
            if (err) return console.log(err);
            if (res[0]) {
                con.query(`SELECT * FROM ucp WHERE DiscordID = ${userid}`, (err, res) => {
                    if (err) return console.log(err);
                    const errEm = new EmbedBuilder()
                        .setColor('Green')
                        .setTitle("Success Message")
                        .setDescription("✅ - You have successfully resubmitted the verification code, please check your DM(Direct Message).")
                        .setTimestamp()
                        .setFooter({ text: `${cfg.serverFooter}` })
                    return interaction.reply({ embeds: [errEm], ephemeral: true })

                    const apani = 0;
                    var randomCode = Math.floor(Math.random() * 99999) + 1;
                    con.query(`UPDATE playerucp SET code ='${randomCode}', Active ='${apani}' WHERE DiscordID = '${userid}'`)

                    const msgEmbed = new EmbedBuilder()
                        .setAuthor({ name: 'GmZ', iconURL: 'https://i.postimg.cc/JzRNFjjn/20230319-102745.png' })
                        .setColor('Blue')
                        .setDescription(`Halo Pemain! UCP anda berhasil terunverify, harap gunakan UCP di bawah ini untuk Login pada InGame`)
                        .addFields({ name: `UCP`, value: `\`\`\`${res[0].ucp_name}\`\`\`` })
                        .addFields({ name: "Pin", value: `> ||${randomCode}||\n\n__Klik kotak hitam untuk melihat pin kamu!__` })
                        .setFooter({ text: "2023 © District" })
                    interaction.member.send({ embeds: [msgEmbed] })
                })
            } else {
                return interaction.reply({ content: `❎ - You haven't registered an account yet`, ephemeral: true })
            }
        })
    }
    if (interaction.customId === "register-buttons") {
        con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
            if (err) return console.log(err);
            if (!res[0]) {
                const registerAkun = new ModalBuilder()
                    .setCustomId("register")
                    .setTitle("Register UCP")

                const namaAkun = new TextInputBuilder()
                    .setCustomId("reg-namaakun")
                    .setLabel("Name UCP")
                    .setPlaceholder("Enter the name do you want")
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(3)

                const row = new ActionRowBuilder().addComponents(namaAkun)
                registerAkun.addComponents(row)
                interaction.showModal(registerAkun)
            } else {
                return interaction.reply({ content: `❎ - You have registered UCP`, ephemeral: true })
            }
        })
    }
    if (interaction.customId === "ingame-stats") {
        con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
            if (err) return console.log(err);
            if (!err) {
                const stats = new ModalBuilder()
                    .setCustomId("stats-account")
                    .setTitle(`Check Stats! UCP: ${res[0].username}`)

                const statsac = new TextInputBuilder()
                    .setCustomId("stats-acc")
                    .setLabel("Account")
                    .setPlaceholder("Input Valid Account Name")
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(8)
                    .setMaxLength(20)

                const row = new ActionRowBuilder().addComponents(statsac)
                stats.addComponents(row)
                interaction.showModal(stats)
            } else {
                return interaction.reply({ content: `❎ - You haven't registered an account yet`, ephemeral: true })
            }
        })
    }
    /*if (interaction.customId === "ingame-log") {
        con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
            if (err) return console.log(err);
            if (res.length > 0) {
                const stats = new ModalBuilder()
                    .setCustomId("chat-account")
                    .setTitle(`Check Stats! UCP: ${res[0].username}`)

                const statsac = new TextInputBuilder()
                    .setCustomId("chat-acc")
                    .setLabel("Account")
                    .setPlaceholder("Input Valid Account Name")
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(8)
                    .setMaxLength(20)

                const row = new ActionRowBuilder().addComponents(statsac)
                stats.addComponents(row)
                interaction.showModal(stats)
            } else {
                return interaction.reply({ content: `❎ - You haven't registered an account yet`, ephemeral: true })
            }
        });
    }*/
    if (interaction.customId === "set-pass") {
        con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
            if (err) return console.log(err);
            if (!err) {
                const pass = new ModalBuilder()
                    .setCustomId("pass")
                    .setTitle(`Change Password! UCP: ${res[0].username}`)

                const pass1 = new TextInputBuilder()
                    .setCustomId("pass-one")
                    .setLabel("New Password")
                    .setPlaceholder("Input Valid UCP Password")
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(4)
                    .setMaxLength(24)

                const pass2 = new TextInputBuilder()
                    .setCustomId("pass-two")
                    .setLabel("New Password Confirmation")
                    .setPlaceholder("Re-Input Valid UCP Password")
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(4)
                    .setMaxLength(24)

                const row = new ActionRowBuilder().addComponents(pass1)
                const row2 = new ActionRowBuilder().addComponents(pass2)
                pass.addComponents(row, row2)
                interaction.showModal(pass)
            } else {
                return interaction.reply({ content: `❎ - You don't have an account!`, ephemeral: true })
            }
        })
    }
    if (interaction.customId === "ingame-bind") {
        con.query(`SELECT * FROM ucp WHERE DiscordID = '${userid}'`, (err, res) => {
            if (err) return console.log(err);
            if (err) {
                const binducp = new ModalBuilder()
                    .setCustomId("bind")
                    .setTitle(`Bind Account!`)

                const akun = new TextInputBuilder()
                    .setCustomId("akun-name")
                    .setLabel("Account to bind")
                    .setPlaceholder("Input Valid UCP Name")
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(4)
                    .setMaxLength(24)

                const pass = new TextInputBuilder()
                    .setCustomId("akun-pass")
                    .setLabel("Password Confirmation")
                    .setPlaceholder("Input Valid UCP Password")
                    .setStyle(TextInputStyle.Short)
                    .setMinLength(4)
                    .setMaxLength(24)


                const row = new ActionRowBuilder().addComponents(akun)
                const row2 = new ActionRowBuilder().addComponents(pass)
                binducp.addComponents(row, row2)
                interaction.showModal(binducp)
            } else {
                return interaction.reply({ content: `❎ - You already have an account! UCP **${res[0].username}**`, ephemeral: true })
            }
        })
    }
});